from ngsolve.comp import MultiGridPreconditioner as MultiGrid
from ngsolve.comp import LocalPreconditioner as Local
from ngsolve.comp import HCurlAMG
from ngsolve.comp import H1AMG
from ngsolve.comp import BDDCPreconditioner as BDDC






